export const accountText01 = `As you could have guessed the first step is creating an account, but! This is and likely always will be a free app so... 
I don’t need your Gmail! The consequence to this is if you lose your password, username, or both, only death awaits you! (I will fix this later!)`;

export const inputDataText02 = `After you create your account you will log in, and every time you visit you will see the dashboard. 
After this you will need to input your fitness data whenever you work out or log in. 
This mainly includes time, effort (based on heart rate zones), resting heart rate, and weight.
According to this you will see stats and information on your progress`;

export const consistencyText03 = `The next part is consistently worshipping the great creator of this app... 
Ok but really this app rewards consistency. Seeing your weight go up or down, the amount of time you spent working out.
Hell, even how low your heart rate gets over time seeing that on a graph brings you that beautiful dopamine.`;
