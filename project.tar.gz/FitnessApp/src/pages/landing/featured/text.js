export const sharingText = `While simple as of writing this, FGraphs allows you to share your fitness data with other users! 
It's just a page where certain data points can be shown to others based on your username.`;

export const analyisText = `FGraphs of course comes with data analysis tools! These are purposely simple, allowing you to track integral data.
Such as resting heart rate, weight, and time spent in workout zones.`;

export const designText = `FGraphs is a custom built fitness tracking app by me! Kaden Wildauer. Apart from my portfolio site, currently it is one of my
most updated sites. With a focus on clean design, creativity and usability. Along with the other boring programmer stuff!`;
