export const underStandingZonesText = `Workout zones show how much effort you put into your workout they are used to calculate effort and energy expenditure.
Your Max Heart Rate (MHR) = 220 - your age.

Zones:
• Zone 1: 50–60% of MHR  
• Zone 2: 60–70% of MHR  
• Zone 3+: Higher intensity

It increase linearly by 10% each zone jump ending at zone 5.
`;

export const loggingInstructionsText = `
After you calculate or estimate your workout zone’s select the time frame you spent in each and submit! 
Stats will show up in the dash board there is also resting and weight so you can track those as well!`;
