import { Outlet } from "react-router-dom";

function PublicRoutes() {
  return <Outlet />;
}

export default PublicRoutes;
