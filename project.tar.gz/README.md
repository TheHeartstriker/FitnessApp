### Origin:
I like fitness and I saw that there was a lot of fitness trackers and the like. They do things along the line of tracking sets and or diet and while that's great on the surface I found that tracking sets can be easily tracked in notepad along with a diet. I don't know if others ever felt the same but it kind of felt like a was of time. Although its a little hard to track diets daily and doing it in a closed of ecosystem in the form of an app loses its purpose of tracking everything precisely. So I wanted to make something that I would actually use and benefit from and maybe others would to.

### Description:
This app tracks a few simple metrics time, effort, weight and heartrate. It was meant to give a look at the overall progress without wasting your time. It tracks things like how much time you have spent in specific zones overall over a period of time and how many calories have you burned in that time. Average heart rate average weight etcetera. I find it nice to zoom out a bit and look at the total effort you have put in that's mainly what this app is a zoomed out look at what you or others with the share feature have done in a period of time.

### Link
If you want to check it out here is the link Link https://www.fgraphs.com
